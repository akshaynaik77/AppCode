-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: quiz
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdetails` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `UserName` text NOT NULL,
  `EmailId` text NOT NULL,
  `Password` text NOT NULL,
  `DOB` date NOT NULL,
  `Country` text NOT NULL,
  `City` text NOT NULL,
  `Address` text NOT NULL,
  `Gender` text NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdetails`
--

LOCK TABLES `userdetails` WRITE;
/*!40000 ALTER TABLE `userdetails` DISABLE KEYS */;
INSERT INTO `userdetails` VALUES (1,'abc','abc','abc','abc@gmail.com','pass123','2002-07-01','India','Ajmer','23,1 ABC','Male'),(2,'abc','abc','abc','abc@gmail.com','pass123','2002-07-01','India','Ajmer','23,1 ABC','Male'),(3,'Sharad','Verma','sharadVerma','sharad.verma23@gmail.com','pass123','2021-12-27','India','indore','223/1, jain colony','male'),(4,'ar','ar','ar','ar','ar123','2022-01-16','India','indore','ar123ar','male'),(5,'a','ar','ar','ar','p111','2022-01-14','China','indore','ar','male'),(6,'','aman','aman','aman','aman','2022-01-12','India','indore','aman','male'),(7,'a','akhil','akhil','akhil','akhil','2022-01-14','India','indore','akhil','male'),(8,'a','ar','ar','ar','ar','2022-01-14','Brazil','bhopal','arr','male'),(9,'art','art','art','art','art','2022-01-20','India','','art','male'),(10,'artty','art','art','art','art','2022-01-20','India','jabalpur','art','male'),(11,'art','art','art','art','art','2022-01-20','India','jabalpur','art','male'),(12,'pen','pen','pen','pen','pen','2022-01-12','India','indore','pen','male'),(13,'pankaj','pankaj','pankaj','pankaj','pankaj','2002-06-23','India','Ajmer','pankaj','Male'),(14,'','','','','','2002-06-21','India','Ajmer','Ramesh','Male'),(15,'ayush','ayush','Ayush','ayush123@gmail.com','Pass123','2002-03-12','India','Jaipur','Ayush','Male'),(16,'amar','khanna','amarKh','amar.khanna@yahoo.com','pass123','2022-01-05','India','indore','23, shastri nagar','male'),(17,'ajay','kamra','ajaykm','ajay.kamra@gmail.com','pass123','2022-01-05','India','indore','23, shastri nagar','male');
/*!40000 ALTER TABLE `userdetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-18 14:37:59
