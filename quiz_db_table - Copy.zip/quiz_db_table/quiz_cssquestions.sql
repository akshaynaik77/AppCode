-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: quiz
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cssquestions`
--

DROP TABLE IF EXISTS `cssquestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cssquestions` (
  `QID` int DEFAULT NULL,
  `Questions` text,
  `Option1` text,
  `Option2` text,
  `Option3` text,
  `Option4` text,
  `Answer` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cssquestions`
--

LOCK TABLES `cssquestions` WRITE;
/*!40000 ALTER TABLE `cssquestions` DISABLE KEYS */;
INSERT INTO `cssquestions` VALUES (1,'What is CSS stands for?','Creative Style Sheet','Colorful Style Sheet','Cascading Style Sheet','Computer Style Sheet','Cascading Style Sheet'),(2,'If we want define style for an unique element, then which css selector will we use?','name','id','class','text','id'),(3,'If we don\'t want to allow a floating div to the left side of an element, which css property will we use ?','margin','clear','float','padding','clear'),(4,'Suppose we want to arragnge five nos. of DIVs so that DIV4 is placed above DIV1. Now, which css property will we use to control the order of stack?','d-index','x-index','s-index','z-index','z-index'),(5,'If we want to show an Arrow as cursor, then which value we will use ?','pointer','arrow','default','arr','default'),(6,'The property in CSS used to change the background color of an element is -','bgcolor','color','background-color','All of the Mentioned','background-color'),(7,'The CSS property used to control the element\'s font-size is -','font-size','text-size','text-edit','none of the mentioned','font-size'),(8,'Which of the following CSS property is used to set the background image of an element?','background-color','background-image','background-attachement','None of above','background-image'),(9,'Which of the following is the correct syntax to display the hyperlinks without any underline?','a {text-decoration : underline;}','a {decoration : no-underline;}','a {text-decoration : none;}','None of the above','a {text-decoration : none;}'),(10,'Which of the following is the correct syntax to make the background-color of all paragraph elements to yellow?','all p {background-color : #yellow;}','all {background-color : yellow;}','p {background-color : #yellow;}','p {background-color : yellow;} ','p {background-color : yellow;}');
/*!40000 ALTER TABLE `cssquestions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-18 14:38:01
